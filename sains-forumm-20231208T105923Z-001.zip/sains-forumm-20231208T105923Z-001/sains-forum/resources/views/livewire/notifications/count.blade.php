<div>
    {{ $count }}
</div>
